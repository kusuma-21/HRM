const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/Loginpage');
const { DashboardPage } = require('../pages/Dashboard');

const username = process.env.ORANGEHRM_USER || 'Admin';
const password = process.env.ORANGEHRM_PASSWORD || 'admin123';

test.describe('OrangeHRM Authentication', () => {
  test.only('TC01 - valid login opens dashboard', async ({ page }) => {
    const login = new LoginPage(page);
    const dashboard = new DashboardPage(page);

    await login.open();
    await login.login(username, password);

    await expect(page).toHaveURL(/dashboard/);
    await dashboard.expectLoaded();
  });

  test('TC02 - invalid credentials are rejected', async ({ page }) => {
    const login = new LoginPage(page);

    await login.open();
    await login.login('invalid_user', 'wrong_password');

    await expect(page.getByText('Invalid credentials'))
      .toBeVisible();

    await expect(page).toHaveURL(/auth\/login/);
  });

  test('TC03 - empty login shows required validation', async ({ page }) => {
    const login = new LoginPage(page);

    await login.open();
    await login.submitEmptyForm();

    await expect(page.getByText('Required').first())
      .toBeVisible();
  });

  test('TC04 - logged-in user can log out', async ({ page }) => {
    const login = new LoginPage(page);
    const dashboard = new DashboardPage(page);

    await login.open();
    await login.login(username, password);
    await dashboard.expectLoaded();
    await dashboard.logout();

    await expect(login.loginButton).toBeVisible();
    await expect(page).toHaveURL(/auth\/login/);
  });
});