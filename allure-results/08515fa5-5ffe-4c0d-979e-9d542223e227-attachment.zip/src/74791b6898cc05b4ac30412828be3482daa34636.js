const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/Loginpage');
const { DashboardPage } = require('../pages/Dashboard');
const { username, password } = require('../test-data/credentials');

test('TC05 - navigate from dashboard to PIM', async ({ page }) => {
  const login = new LoginPage(page);
  const dashboard = new DashboardPage(page);

  await login.open();
  await login.login(username, password);

  await dashboard.expectLoaded();
  await dashboard.openPIM();

  await expect(page).toHaveURL(/pim/);
  await expect(
    page.getByRole('heading', { name: 'PIM' })
  ).toBeVisible();
});
