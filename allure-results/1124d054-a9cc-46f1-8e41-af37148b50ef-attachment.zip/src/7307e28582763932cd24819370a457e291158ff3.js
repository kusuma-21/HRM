const { test: base, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/Loginpage');
const { DashboardPage } = require('../pages/Dashboard');
const { username, password } = require('../test-data/credentials');

const test = base.extend({
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },
  dashboardPage: async ({ page }, use) => {
    await use(new DashboardPage(page));
  },
});

test.describe('OrangeHRM Authentication', () => {

  test.beforeEach(async ({ loginPage }) => {
    await loginPage.open();
  });

  test('TC01 - valid login opens dashboard', async ({ page, loginPage, dashboardPage }) => {
    await loginPage.login(username, password);

    await expect(page).toHaveURL(/dashboard/);
    await dashboardPage.expectLoaded();
  });

  test('TC02 - invalid credentials are rejected', async ({ page, loginPage }) => {
    await loginPage.login('invalid_user', 'wrong_password');

    await expect(page.getByText('Invalid credentials')).toBeVisible();
  });

  test('TC03 - empty login shows required validation', async ({ page, loginPage }) => {
    await loginPage.submitEmptyForm();

    await expect(page.getByText('Required').first()).toBeVisible();
  });

  test.describe('Authenticated user', () => {
    test.beforeEach(async ({ loginPage, dashboardPage }) => {
      await loginPage.login(username, password);
      await dashboardPage.expectLoaded();
    });

    test('TC04 - logged-in user can log out', async ({ loginPage, dashboardPage }) => {
      await dashboardPage.logout();

      await expect(loginPage.loginButton).toBeVisible();
    });
  });
});