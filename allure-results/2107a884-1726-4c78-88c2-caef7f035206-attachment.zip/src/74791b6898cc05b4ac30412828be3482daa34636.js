const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/Loginpage');
const { DashboardPage } = require('../pages/Dashboard');
const { PIMPage } = require('../pages/PIM');
const { username, password } = require('../test-data/credentials');

test.describe('OrangeHRM PIM workflow', () => {
  test.beforeEach(async ({ page }) => {
    const login = new LoginPage(page);
    const dashboard = new DashboardPage(page);

    await login.open();
    await login.login(username, password);
    await dashboard.expectLoaded();
  });

  test('TC05 - navigate to PIM, add an employee, and log out', async ({ page }) => {
    const dashboard = new DashboardPage(page);
    const pim = new PIMPage(page);
    const firstName = `Test${Date.now()}`;
    const lastName = 'Employee';

    await dashboard.openPIM();
    await expect(page).toHaveURL(/pim/);
    await expect(page.getByRole('heading', { name: 'PIM' })).toBeVisible();

    await pim.openAddEmployee();
    await pim.addEmployee(firstName, lastName);

    await expect(page.getByRole('heading', { name: 'Personal Details' })).toBeVisible();
    await expect(pim.firstName).toHaveValue(firstName);
    await expect(pim.lastName).toHaveValue(lastName);

    await dashboard.logout();
    await expect(page).toHaveURL(/auth\/login/);
  });
});
